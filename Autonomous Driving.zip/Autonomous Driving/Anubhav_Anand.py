## ---------------------------- ##
##
## Example student submission code for autonomous driving challenge.
## You must modify the train and predict methods and the NeuralNetwork class. 
## 
## ---------------------------- ##

import numpy as np
import cv2
from tqdm import tqdm
import time
import matplotlib.pyplot as plt
import scipy.interpolate

path_to_images = 'data/training/images'
csv_file = 'data/training/steering_angles.csv'

# y_min = 0
# y_max = 0

# def preprocess(x):
#   pass
#   #return processed_x




def scale_input_angle (steering_angles):
    scaled_input_angle = []
    for j in range (len(steering_angles)):
      scaled_input_angle.append(steering_angles[j])
      
    # scaled_input_angle = (scaled_input_angle - min(scaled_input_angle) ) / (max(scaled_input_angle) - min(scaled_input_angle))

    return scaled_input_angle
  

def scale_input_image(frame_nums):
    scaled_input_image = []
    for i in range (len(frame_nums)):
      input_image = cv2.imread(path_to_images + '/' + str(i).zfill(4) + '.jpg')
      
      input_image = np.mean(input_image, axis=2)
      input_image = input_image / 255
      input_image = cv2.resize(input_image, (60, 64))
      input_image = input_image/np.amax(input_image, axis=0)
      scaled_input_image.append(input_image.flatten())

      # print(input_image.shape)

    return scaled_input_image

def train(path_to_images = 'data/training/images', 
          csv_file = 'data/training/steering_angles.csv'):
    '''
    First method you need to complete. 
    Args: 
    path_to_images = path to jpg image files
    csv_file = path and filename to csv file containing frame numbers and steering angles. 
    Returns: 
    NN = Trained Neural Network object 
    '''

    # You may make changes here if you wish. 
    # Import Steering Angles CSV
    data = np.genfromtxt(csv_file, delimiter = ',')
    frame_nums = data[:,0]
    steering_angles = data[:,1]

    # You could import your images one at a time or all at once first, 
    # here's some code to import a single image:

    input = np.array(scale_input_image(frame_nums))
    output = np.array(scale_input_angle(steering_angles))
    y_min = np.min(output)
    # print(y_min)
    y_max = np.max(output)
    # print(y_max)
    output = (output - y_min ) / (y_max - y_min)
    # print(output)
    
    
    output = np.reshape(output, (1500, 1))

    # print("Input: ", input.shape)
    # print("Output: ", output.shape)

    total_iterations = 3000
    lr = 0.001

    total_loss = []
    NN = NeuralNetwork()
    for i in range(total_iterations):
        grads = NN.computeGradients(input,output)
        params = NN.getParams()
        NN.setParams(params - lr*grads)
        total_loss.append(NN.costFunction(input,output))

    # print(total_loss[len(total_loss)-1])

    # fig = figure(0, (12,6))
    # plot(total_loss, linewidth = 3); grid(1); xlabel('iterations'); ylabel('loss');

    return NN

def predict(NN, image_file):
    '''
    Second method you need to complete. 
    Given an image filename, load image, make and return predicted steering angle in degrees. 
    '''
    im_full = cv2.imread(image_file)
    im_full = np.mean(im_full, axis=2)
    im_full = im_full / 255
    im_full = cv2.resize(im_full, (60, 64)) 
    im_full = im_full/np.amax(im_full, axis=0)
    yHat = NN.forward(im_full.flatten())
   
    Y = yHat * (26-(-168)) + (-168)
    # print(yHat,Y)
    return Y[0]

class NeuralNetwork(object):
    def __init__(self):        
        '''
        Neural Network Class, you may need to make some modifications here!
        '''
        self.inputLayerSize = 3840
        self.outputLayerSize = 1
        self.hiddenLayerSize = 64
        
        #Weights (parameters)
        self.W1 = np.random.randn(self.inputLayerSize,self.hiddenLayerSize)
        self.W2 = np.random.randn(self.hiddenLayerSize,self.outputLayerSize)
    
    def forward(self, X):
        #Propogate inputs though network
        self.z2 = np.dot(X, self.W1)
        self.a2 = self.sigmoid(self.z2)
        self.z3 = np.dot(self.a2, self.W2)
        yHat = self.sigmoid(self.z3) 
        return yHat
        
    def sigmoid(self, z):
        #Apply sigmoid activation function to scalar, vector, or matrix
        return 1/(1+np.exp(-z))
    
    def sigmoidPrime(self,z):
        #Gradient of sigmoid
        return np.exp(-z)/((1+np.exp(-z))**2)
    
    def costFunction(self, X, y):
        #Compute cost for given X,y, use weights already stored in class.
        self.yHat = self.forward(X)
        J = 0.5*sum((y-self.yHat)**2)
        return J
        
    def costFunctionPrime(self, X, y):
        #Compute derivative with respect to W and W2 for a given X and y:
        self.yHat = self.forward(X)
        
        delta3 = np.multiply(-(y-self.yHat), self.sigmoidPrime(self.z3))
        dJdW2 = np.dot(self.a2.T, delta3)
        
        delta2 = np.dot(delta3, self.W2.T)*self.sigmoidPrime(self.z2)
        dJdW1 = np.dot(X.T, delta2)  
        
        return dJdW1, dJdW2
    
    #Helper Functions for interacting with other classes:
    def getParams(self):
        #Get W1 and W2 unrolled into vector:
        params = np.concatenate((self.W1.ravel(), self.W2.ravel()))
        return params
    
    def setParams(self, params):
        #Set W1 and W2 using single paramater vector.
        W1_start = 0
        W1_end = self.hiddenLayerSize * self.inputLayerSize
        self.W1 = np.reshape(params[W1_start:W1_end], (self.inputLayerSize , self.hiddenLayerSize))
        W2_end = W1_end + self.hiddenLayerSize*self.outputLayerSize
        self.W2 = np.reshape(params[W1_end:W2_end], (self.hiddenLayerSize, self.outputLayerSize))
        
    def computeGradients(self, X, y):
        dJdW1, dJdW2 = self.costFunctionPrime(X, y)
        return np.concatenate((dJdW1.ravel(), dJdW2.ravel()))