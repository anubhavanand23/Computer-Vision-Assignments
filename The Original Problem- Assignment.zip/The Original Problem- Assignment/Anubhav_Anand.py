## ---------------------------- ##
## 
## sample_student.py
##
## Example student submission for programming challenge. A few things: 
## 1. Before submitting, change the name of this file to your firstname_lastname.py.
## 2. Be sure not to change the name of the method below, classify.py
## 3. In this challenge, you are only permitted to import numpy and methods from 
##    the util module in this repository. Note that if you make any changes to your local 
##    util module, these won't be reflected in the util module that is imported by the 
##    auto grading algorithm. 
## 4. Anti-plagarism checks will be run on your submission
##
##
## ---------------------------- ##


import numpy as np

## 1. It's okay to import whatever you want from the local util module if you would like:
#  You can import functions from util folder like this


from util.filters import filter_2d
from util.image import convert_to_grayscale


## 2. It is okay to define methods outside classify


def classify(im):
    
    #scaling the image
    #scaled_img = im/255
    
    im = im[12:244,12:244]

    #converting the image to gryscale
    grayscale_img = convert_to_grayscale(im/255.)

    
    Kx = np.array([[1, 0, -1],
                   [2, 0, -2],
                   [1, 0, -1]])
    
    Ky = np.array([[1, 2, 1],
                   [0, 0, 0],
                   [-1, -2, -1]])
    
    Gx = filter_2d(grayscale_img, Kx)
    Gy = filter_2d(grayscale_img, Ky)

    G_magnitude = np.sqrt(Gx**2+Gy**2)

    #compute direction

        #G_magnitude_max = np.max(G_magnitude)
    
       
    G_magnitude_max = np.max(np.sqrt(Gx**2+Gy**2))

    #print(G_magnitude_max)
        
    if(G_magnitude_max<= 1.69):
      return 'ball'
    elif (G_magnitude_max>= 1.7 and G_magnitude_max <= 2.4 ):
      return 'cylinder'
    else:
      return 'brick'

